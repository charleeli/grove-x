// file      : odb/mysql/statements-base.cxx
// copyright : Copyright (c) 2005-2015 Code Synthesis Tools CC
// license   : GNU GPL v2; see accompanying LICENSE file

#include <odb/mysql/statements-base.hxx>

namespace odb
{
  namespace mysql
  {
    statements_base::
    ~statements_base ()
    {
    }
  }
}
